export interface Contacts{
    firstName : string;
    lastName : string;
    phone : string;
    id : number;
}