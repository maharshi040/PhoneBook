import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { Contacts } from '../models/Contacts';

export interface Items {
  key: string;
  value: any;
}

@Injectable({
  providedIn: 'root'
})
export class ObservableService {

  item!: Items;
  itemArray: Items[] = [];

  constructor(
  ) { }

  /**
   * Insert key & value to service storage
   * @param key : Storage key
   * @param value : Storage value
   */
  public setSharingData(key: string, value: any): void {
    this.removeSharedData(key);
    this.item = { key, value };
    this.itemArray.push(this.item);
  }

  /**
   * Get value of key from the service storage
   * @param key : Storage key
   * @param value : Storage value
   */
  public getSharedData(key: string): any {
    if (this.itemArray && this.itemArray.length > 0) {
      const filteredObject = this.itemArray.find(f => f.key === key);
      if (filteredObject) {
        return filteredObject.value;
      }
    }
  }

  /**
   * Remove key from the service storage
   * @param key : Storage key
   */
  public removeSharedData(key: string): any {
    const objectIndex = this.itemArray.findIndex(i => i.key === key);

    if (objectIndex !== -1) {
      this.itemArray.splice(objectIndex, 1);
      return true;
    } else {
      return false;
    }
  }

  /**
   * To Clear all data
   */
  public reset(): any {
    this.itemArray = [];
    return true;
  }

  set contactToBeEdited(value: Contacts) {
    this.setSharingData("edit", value);
  }
  get contactToBeEdited(): Contacts {
    return this.getSharedData("edit");
  }

  set newContact(value : any){
    this.setSharingData("new product", value);
  }
  get newContact(): any{
    return this.getSharedData("new product");
  }

  set navigateFromPage(value :string){
    this.setSharingData("navigate from", value);
  }
  get navigateFromPage(): string{
    return this.getSharedData("navigate from");
  }

}
