import { TestBed } from '@angular/core/testing';
import { Contacts } from '../models/Contacts';

import { ObservableService } from './observable.service';

describe('ObservableService', () => {
  let service: ObservableService;
  let contact : Contacts = 
  {
      firstName: "Amit",
      lastName: "Roy",
      phone: "9876543210",
      id: 1
    }    
  

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ObservableService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should should contain the contact to be edited', ()=>{
    service.contactToBeEdited = contact;
    expect(service.contactToBeEdited).toEqual(contact);
  });

  it('should should contain the new contact to be updated/added', ()=>{
    service.newContact = contact;
    expect(service.newContact).toEqual(contact);
  });

  it('should should contain the page name from where user is navigating', ()=>{
    service.navigateFromPage = 'edit-contact';
    expect(service.navigateFromPage).toEqual('edit-contact');
  });

});
