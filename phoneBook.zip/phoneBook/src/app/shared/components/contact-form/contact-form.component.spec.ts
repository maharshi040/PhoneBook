import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { Contacts } from '../../models/Contacts';

import { ContactFormComponent } from './contact-form.component';
import { InputValidator, NumberValidator } from './Validator';

describe('ContactFormComponent', () => {
  let component: ContactFormComponent;
  let fixture: ComponentFixture<ContactFormComponent>;
  let contact : Contacts = {
      firstName: "Amit",
      lastName: "Roy",
      phone: "9876543210",
      id: 1
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule, 
      ],
      declarations: [ ContactFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to edit contact when user click edit contact', ()=>{
    const routerstub: Router = TestBed.get(Router);
    spyOn(routerstub, 'navigate');
    component.update();
    fixture.detectChanges();
    expect(routerstub.navigate).toHaveBeenCalledWith(['home/view-contacts']);
  });

  it('Should reset all input fields on click of reset', ()=>{
    component.reset();
    fixture.detectChanges();
    expect(component.firstNameFormControl.value).toBeNull();
    expect(component.lastNameFormControl.value).toBeNull();
    expect(component.phoneNumberFormControl.value).toBeNull();
  });

  it('should contain title as Edit Contact when user clicks edit contact', ()=>{
    component.contact = contact;
    component.setDataOnPageLoad();
    fixture.detectChanges();
    expect(component.title).toBe('Edit Contact');
    expect(component.buttonText).toBe('Update');
  });

  it('should set fields with values when user clicks edit option for a contact', ()=>{
    component.contact = contact;
    component.setDataOnPageLoad();
    fixture.detectChanges();
    expect(component.firstNameFormControl.value).toBe(contact.firstName);
    expect(component.lastNameFormControl.value).toBe(contact.lastName);
    expect(component.phoneNumberFormControl.value).toBe(Number(contact.phone));
  });

  it('should contain fields empty when user navigated from add contacts page', ()=>{
    component.setDataOnPageLoad();
    fixture.detectChanges();
    expect(component.firstNameFormControl.value).toEqual('');
    expect(component.lastNameFormControl.value).toEqual('');
    expect(component.phoneNumberFormControl.value).toEqual('');
  })

it('should set validators to form controls', ()=>{
  component.setFormControls();
  fixture.detectChanges();
  expect(component.firstNameFormControl.setValidators).toBeTruthy();
  expect(component.lastNameFormControl.setValidators).toBeTruthy();
  expect(component.phoneNumberFormControl.setValidators).toBeTruthy();
});

it('phone number control should not accept special characters', ()=>{
  component.phoneNumberFormControl.setValidators(NumberValidator());
  component.phoneNumberFormControl.setValue('AbC');
  component.phoneNumberFormControl.updateValueAndValidity();
  fixture.detectChanges();
  expect(component.phoneNumberFormControl.valid).toBe(false);
});

it('phone number control should accept numbers', ()=>{
  component.phoneNumberFormControl.setValidators(NumberValidator());
  component.phoneNumberFormControl.setValue(9087690876);
  component.phoneNumberFormControl.updateValueAndValidity();
  fixture.detectChanges();
  expect(component.phoneNumberFormControl.valid).toBe(true);
});

it('first name form control should not accept special characters', ()=>{
  component.firstNameFormControl.setValidators(InputValidator());
  component.firstNameFormControl.setValue('@fgsg!');
  component.firstNameFormControl.updateValueAndValidity();
  fixture.detectChanges();
  expect(component.firstNameFormControl.valid).toBe(false);
});

it('first name form control should  accept alphabets', ()=>{
  component.firstNameFormControl.setValidators(InputValidator());
  component.firstNameFormControl.setValue('maharshi');
  component.firstNameFormControl.updateValueAndValidity();
  fixture.detectChanges();
  expect(component.firstNameFormControl.valid).toBe(true);
});

it('last name form control should not accept special characters', ()=>{
  component.lastNameFormControl.setValidators(InputValidator());
  component.lastNameFormControl.setValue('@fgsg!');
  component.lastNameFormControl.updateValueAndValidity();
  fixture.detectChanges();
  expect(component.lastNameFormControl.valid).toBe(false);
});

it('last name form control should  accept alphabets', ()=>{
  component.lastNameFormControl.setValidators(InputValidator());
  component.lastNameFormControl.setValue('maharshi');
  component.lastNameFormControl.updateValueAndValidity();
  fixture.detectChanges();
  expect(component.lastNameFormControl.valid).toBe(true);
});

it('should set isAddContact to true, when user navigated from add contact page', ()=>{
  component.setDataOnPageLoad();
  fixture.detectChanges();
  expect(component.isAddContact).toBeTrue();
});

});
