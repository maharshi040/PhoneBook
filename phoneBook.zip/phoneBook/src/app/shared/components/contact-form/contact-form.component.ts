import { Component, Input, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { Contacts } from '../../models/Contacts';
import { ObservableService } from '../../services/observable.service';
import { NumberValidator, InputValidator} from './Validator';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrls: ['./contact-form.component.scss']
})
export class ContactFormComponent implements OnInit {

  @Input() contact! : Contacts;
  @Input() length ! : number;
  FormControl = new FormControl('', []);
  firstNameFormControl = new FormControl('', []);
  lastNameFormControl = new FormControl('', []);
  phoneNumberFormControl = new FormControl('', []);
  title : string = "Add Contact";
  buttonText : string = "Add";
  isPageLoaded: boolean = false;
  isUpdated : boolean = false;
  isAddContact:boolean = false;
  isEditContact : boolean = false;
  id! :number;

  constructor(
    private observableService : ObservableService,
    private router : Router
  ) { }

  ngOnInit(): void {
    this.setFormControls();
    this.setDataOnPageLoad();
  }

  setFormControls():void{
    this.firstNameFormControl.setValidators(InputValidator());
    this.lastNameFormControl.setValidators(InputValidator());
    this.phoneNumberFormControl.setValidators(NumberValidator());
  }

  setDataOnPageLoad():void{

    if(this.contact && this.contact != null ){
      this.isEditContact = true;
      this.title = "Edit Contact";
      this.buttonText = "Update";
      this.firstNameFormControl.setValue(this.contact.firstName);
      this.lastNameFormControl.setValue(this.contact.lastName);
      this.phoneNumberFormControl.setValue(Number(this.contact.phone));
      this.isPageLoaded = true;
    }
    else{
      this.isPageLoaded = true;
      this.isAddContact = true;
    }
  }

  update():void{
    debugger;
    if(this.isEditContact){
      this.id = this.contact.id;
    }
    else if(this.isAddContact){
      this.id = 0;
    }
     const param  = {
        id: this.id,
        firstName : this.firstNameFormControl.value,
        lastName : this.lastNameFormControl.value,
        phone : this.phoneNumberFormControl.value
      }
    debugger;

    this.observableService.newContact = param;

    if(this.isEditContact){
      this.observableService.navigateFromPage ="editContact";
    }
    else if(this.isAddContact){
      this.observableService.navigateFromPage ="addContact";
    }
    this.router.navigate(['home/view-contacts']);
  }

  reset():void{
    this.firstNameFormControl.reset();
    this.lastNameFormControl.reset();
    this.phoneNumberFormControl.reset();
  }

}
