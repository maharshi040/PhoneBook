import { AbstractControl } from '@angular/forms';
import { ValidatorFn } from '@angular/forms';


export function NumberValidator(): ValidatorFn {
    let onlyDigits = new RegExp('^[0-9]*$')
    return (control: AbstractControl): { [key: string]: any } | null => {
        if (!control.value) 
            return { isRequiredField: { value: true } };
        if((control.value).length > 10)
            return { phoneLength: { value: true}};
        if (!onlyDigits.test(control.value)) {
            return { onlyNumbers: { value: true } };
        }

        return null;
    };
}


export function InputValidator(): ValidatorFn {
    let noSpecialChar = new RegExp('^[A-Za-z0-9\-\' ]*$');
    return (control: AbstractControl): { [key: string]: any } | null => {

        if (!control.value) {
            return { requiredField: { value: true } };
        }

        if ((control.value).length > 20) {
            return { maxLength: { value: true } };
        }

        if (!noSpecialChar.test(control.value)) {
            return { isSpecialCharacterExist: { value: true } };
        }

        return null;
    };
}
