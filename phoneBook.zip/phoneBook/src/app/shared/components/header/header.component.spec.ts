import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { HeaderComponent } from './header.component';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HeaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contain logo for PhoneBook', () => {
    const logo = fixture.debugElement.query(By.css('#logo'));
    expect(logo).toBeTruthy();
  });

  it('Should contain anchor tag on navbar on navbar', ()=>{
    const text = fixture.debugElement.query(By.css('#navbar'));
    expect(text.name).toBe('a');
  });

  it('Should contain PhoneBook text on navbar', ()=>{
    const text = fixture.debugElement.query(By.css('#navbar'));
    expect(text.nativeElement.textContent).toBe(' PhoneBook ');
  });
  
});
