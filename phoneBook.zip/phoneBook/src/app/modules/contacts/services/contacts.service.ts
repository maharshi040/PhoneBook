import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import {Observable, throwError} from 'rxjs';
import {catchError,retry} from 'rxjs/internal/operators/';
import { Contacts } from 'src/app/shared/models/Contacts';

@Injectable({
  providedIn: 'root'
})
export class ContactsService {

  contacts:any[] =[];
  constructor(
    private http : HttpClient
  ) { }

  contactsBaseUrl : string = "https://my-json-server.typicode.com/"
  contactsSuffixurl : string = "voramahavir/contacts-mock-response/"
  conatctsEndpoint : string = "contacts"

  //get contacts from API
    getContacts():Observable<Contacts[]>{
      const apiUrl= this.contactsBaseUrl + this.contactsSuffixurl + this.conatctsEndpoint;
      return this.http.get<Contacts[]>(apiUrl).pipe( 
      retry(1),
      catchError(this.handleError))
    }

  // Error handling
  handleError(error: HttpErrorResponse) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(() => {
      return errorMessage;
    });
  }

  
}
