import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddContactsComponent } from './components/add-contacts/add-contacts.component';
import { EditContactsComponent } from './components/edit-contacts/edit-contacts.component';
import { HomeComponent } from './components/home/home.component';
import { ViewContactsComponent } from './components/view-contacts/view-contacts.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent
  },
  {
    path: 'view-contacts',
    component: ViewContactsComponent
  },
  {
    path: 'add-contact',
    component: AddContactsComponent
  },
  {
    path: 'edit-contacts',
    component: EditContactsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContactsRoutingModule { }
