import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ContactsRoutingModule } from './contacts-routing.module';
import { HomeComponent } from './components/home/home.component';
import { AddContactsComponent } from './components/add-contacts/add-contacts.component';
import { EditContactsComponent } from './components/edit-contacts/edit-contacts.component';
import { ViewContactsComponent } from './components/view-contacts/view-contacts.component';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatCardModule} from '@angular/material/card';
import {MatIconModule} from '@angular/material/icon';
import { ContactFormComponent } from 'src/app/shared/components/contact-form/contact-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    HomeComponent,
    AddContactsComponent,
    EditContactsComponent,
    ViewContactsComponent,
    ContactFormComponent
    ],
  imports: [
    CommonModule,
    ContactsRoutingModule,
    MatFormFieldModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatToolbarModule,
    MatCardModule,
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
  ]
})
export class ContactsModule { }
