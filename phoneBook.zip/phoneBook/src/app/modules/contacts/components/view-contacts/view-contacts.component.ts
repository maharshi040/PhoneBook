import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { forkJoin, Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/internal/operators';
import { Contacts } from 'src/app/shared/models/Contacts';
import { ObservableService } from 'src/app/shared/services/observable.service';
import { ContactsService } from '../../services/contacts.service';

@Component({
  selector: 'app-view-contacts',
  templateUrl: './view-contacts.component.html',
  styleUrls: ['./view-contacts.component.scss']
})
export class ViewContactsComponent implements OnInit, OnDestroy {
  
  notifier = new Subject();
  newContact! : Contacts;
  contacts! : any[];
  isPageLoaded : boolean = false;
  isDeleted : boolean = false;
  isFromEditContactPage : boolean = false;
  isFromAddContactPage : boolean = false;
  fromPage! : string;

  constructor(
    private contactsService : ContactsService,
    private router : Router,
    private observableService : ObservableService
  ) { }

  ngOnInit(): void {
    this.setDataOnPageLoad();
  }

  setDataOnPageLoad(){
  this.getContacts();
  }

  //to get contacts
   getContacts(): void{
     this.contactsService.getContacts().subscribe((res:Contacts[])=>{
      if(res){
        this.contacts = res;
        this.CheckForEditAndAddContact();
      }
     });
  }

  CheckForEditAndAddContact(){
    this.fromPage = this.observableService.navigateFromPage;

   if(this.fromPage == "editContact"){
     this.isFromEditContactPage = true;
   }
   else if (this.fromPage == "addContact"){
     this.isFromAddContactPage = true;
   }

  this.newContact = this.observableService.newContact;
    debugger;

    if(this.isFromEditContactPage){
      this.contacts = this.contacts.filter( f => f.id != this.newContact.id);
      console.log("Filtered :", this.contacts);
      this.contacts.push(this.newContact);
    }
    else if(this.isFromAddContactPage){
      let newId = this.contacts.length + 1;
      this.newContact.id = newId;
      this.contacts.unshift(this.newContact);
    }
   this.isPageLoaded = true;
  }

  // To delete the product
  delete(deletedContact:Contacts):void{
   this.isPageLoaded = false;
   this.contacts = this.contacts.filter( contact => contact.id != deletedContact.id);
   this.isDeleted = true;
   setTimeout(()=>{
     this.isPageLoaded = true;
     this.isDeleted = false;
   }, 2500);

  }

  edit(contact:Contacts):void{
    this.observableService.contactToBeEdited = contact;
    this.router.navigate(['home/edit-contacts']);
  }

  ngOnDestroy(): void {
    this.notifier.next();
    this.notifier.complete();
  }


}
