import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ViewContactsComponent } from './view-contacts.component';
import { Contacts } from 'src/app/shared/models/Contacts';
import { ContactsService } from '../../services/contacts.service';
import { of } from 'rxjs';
import { By } from '@angular/platform-browser';
import { Router } from '@angular/router';

describe('ViewContactsComponent', () => {
  let component: ViewContactsComponent;
  let fixture: ComponentFixture<ViewContactsComponent>;
  let contactsResponse : Contacts[]= [
    {
      firstName: "Amit",
      lastName: "Roy",
      phone: "9876543210",
      id: 1
    }    
  ]
  let contact : Contacts = {
      firstName: "Amit",
      lastName: "Roy",
      phone: "9876543210",
      id: 1
  }
  let getContactsResponse : Contacts[] = [
    {
      firstName: "Amit",
      lastName: "Roy",
      phone: "9876543210",
      id: 1
    },
    {
      firstName: "marsh",
      lastName: "R",
      phone: "7067870678",
      id: 2
    }        
  ]

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
      ],
      declarations: [ ViewContactsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewContactsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getContacts method', ()=>{
    let service = fixture.debugElement.injector.get(ContactsService);
    spyOn(service, 'getContacts').and.returnValue(of(contactsResponse));
    expect(component.getContacts).toBeTruthy();
  });

  it('should contain h1 tag', () => {
    const heading = fixture.debugElement.query(By.css('#heading'));
    expect(heading).toBeTruthy();
  });

  it('should contain main heading as Contacts', () => {
    const heading = fixture.debugElement.query(By.css('#heading'));
    expect(heading.nativeElement.textContent).toEqual('Contacts');
  });

  it('should expect isFromAddConntactPage to be false, when page is navigated from edit contacts page', ()=>{
    component.CheckForEditAndAddContact();
    component.fromPage = "editContact";
    fixture.detectChanges();
    expect(component.isFromAddContactPage).toBe(false);
  });

  it('should expect isFromEditContactPage to be false, when page is navigated from add contact page', ()=>{
    component.fromPage = "addContact";
    component.CheckForEditAndAddContact();
    fixture.detectChanges();
    expect(component.isFromEditContactPage).toBe(false);
  });

  it('should delete the contact that user selected', ()=>{
    component.contacts = getContactsResponse;
    component.delete(contact);
    fixture.detectChanges();
    expect(component.contacts.length).toBe(1);
  });

  it('should navigate to edit contact when user click edit contact', ()=>{
    const routerstub: Router = TestBed.get(Router);
    spyOn(routerstub, 'navigate');
    component.edit(contact);
    fixture.detectChanges();
    expect(routerstub.navigate).toHaveBeenCalledWith(['home/edit-contacts']);
  });

});