import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { Contacts } from 'src/app/shared/models/Contacts';
import { ObservableService } from 'src/app/shared/services/observable.service';

@Component({
  selector: 'app-edit-contacts',
  templateUrl: './edit-contacts.component.html',
  styleUrls: ['./edit-contacts.component.scss']
})
export class EditContactsComponent implements OnInit {

  editContact! : Contacts;

  constructor(
    public observableService : ObservableService,
  ) { }


  ngOnInit(): void {
   this.editContact = this.observableService.contactToBeEdited
  }

}
