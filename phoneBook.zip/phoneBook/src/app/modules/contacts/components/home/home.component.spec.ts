import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

import { HomeComponent } from './home.component';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule, 
      ],
      declarations: [ HomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to add contact when user clicks on add contacts', ()=>{
    const routerstub: Router = TestBed.get(Router);
    spyOn(routerstub, 'navigate');
    component.GoTo('add-contact');
    fixture.detectChanges();
    expect(routerstub.navigate).toHaveBeenCalledWith(['home/add-contact']);
  });

  it('should navigate to view contacts when user clicks on view contacts', ()=>{
    const routerstub: Router = TestBed.get(Router);
    spyOn(routerstub, 'navigate');
    component.GoTo('view-contacts');
    fixture.detectChanges();
    expect(routerstub.navigate).toHaveBeenCalledWith(['home/view-contacts']);
  });

  it('should contain h1 tag', () => {
    const heading = fixture.debugElement.query(By.css('#heading'));
    expect(heading).toBeTruthy();
  });

  it('should contain main heading as Contacts', () => {
    const heading = fixture.debugElement.query(By.css('#heading'));
    expect(heading.nativeElement.textContent).toEqual('Welcome to PhoneBook');
  });

});
